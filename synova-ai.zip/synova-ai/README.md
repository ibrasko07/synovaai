# ✦ Synova AI

Plateforme SaaS IA type ChatGPT avec monétisation intégrée, construite avec Next.js 14.

## Stack

- **Next.js 14** App Router
- **OpenAI** GPT-4o mini
- **SumUp** pour les paiements
- **TypeScript** strict

## Démarrage rapide

```bash
# 1. Installer les dépendances
npm install

# 2. Configurer les variables d'environnement
cp .env.example .env.local
# → Éditer .env.local et ajouter votre clé OpenAI

# 3. Lancer en développement
npm run dev
```

## Variables d'environnement

| Variable | Description |
|----------|-------------|
| `OPENAI_API_KEY` | Clé API OpenAI (requis) |

## Structure

```
synova-ai/
├── app/
│   ├── api/ai/route.ts     # Route API OpenAI
│   ├── pricing/page.tsx    # Page pricing
│   ├── page.tsx            # Chat principal
│   ├── layout.tsx          # Layout racine
│   └── globals.css         # Styles globaux
├── lib/
│   └── openai.ts           # Client OpenAI
├── render.yaml             # Config Render
└── package.json
```

## Déploiement sur Render

1. Pousser le code sur GitHub
2. Sur [render.com](https://render.com) → New Web Service → connecter le repo
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Ajouter la variable d'environnement `OPENAI_API_KEY`

## Fonctionnalités

- **Chat IA** — GPT-4o mini, réponses rapides, historique
- **Monétisation** — 5 crédits gratuits, blocage + bannière upgrade
- **Paiements SumUp** — 3 plans × 2 cycles (mensuel/annuel)
- **Design premium** — Dark mode, animations, responsive
