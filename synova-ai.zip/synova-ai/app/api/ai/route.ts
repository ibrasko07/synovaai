import { NextRequest, NextResponse } from "next/server";
import openai from "@/lib/openai";

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: "Messages invalides." },
        { status: 400 }
      );
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "Tu es Synova AI, un assistant IA intelligent, précis et bienveillant. Tu réponds toujours en français sauf si l'utilisateur te parle dans une autre langue. Tu es concis, utile et professionnel.",
        },
        ...messages,
      ],
      max_tokens: 1024,
      temperature: 0.7,
    });

    const reply = completion.choices[0]?.message?.content ?? "";

    return NextResponse.json({ reply });
  } catch (error: unknown) {
    console.error("[AI Route Error]", error);

    if (
      typeof error === "object" &&
      error !== null &&
      "status" in error &&
      (error as { status: number }).status === 401
    ) {
      return NextResponse.json(
        { error: "Clé API OpenAI invalide." },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: "Erreur serveur. Réessaie dans un instant." },
      { status: 500 }
    );
  }
}
