"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Sparkles,
  Check,
  Zap,
  Crown,
  Rocket,
  ArrowLeft,
  Star,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Plan {
  name: string;
  icon: React.ReactNode;
  price: { monthly: number; annual: number };
  link: { monthly: string; annual: string };
  color: string;
  gradient: string;
  popular?: boolean;
  features: string[];
}

// ─── Plans ────────────────────────────────────────────────────────────────────

const PLANS: Plan[] = [
  {
    name: "Starter",
    icon: <Zap size={20} />,
    price: { monthly: 29, annual: 290 },
    link: {
      monthly: "https://pay.sumup.com/b2c/QTK39X1R",
      annual: "https://pay.sumup.com/b2c/QI4G3BM2",
    },
    color: "#7c6aff",
    gradient: "linear-gradient(135deg, #7c6aff, #6254e8)",
    features: [
      "500 messages / mois",
      "Accès GPT-4o mini",
      "Historique 30 jours",
      "Support email",
      "Export conversations",
    ],
  },
  {
    name: "Pro",
    icon: <Crown size={20} />,
    price: { monthly: 79, annual: 790 },
    link: {
      monthly: "https://pay.sumup.com/b2c/QWSI8XON",
      annual: "https://pay.sumup.com/b2c/QT0BAKOR",
    },
    color: "#a78bfa",
    gradient: "linear-gradient(135deg, #a78bfa, #7c6aff)",
    popular: true,
    features: [
      "Messages illimités",
      "GPT-4o mini prioritaire",
      "Historique illimité",
      "Support prioritaire",
      "API access",
      "Personnalisation IA",
    ],
  },
  {
    name: "Business",
    icon: <Rocket size={20} />,
    price: { monthly: 229, annual: 2290 },
    link: {
      monthly: "https://pay.sumup.com/b2c/QRNV5G24",
      annual: "https://pay.sumup.com/b2c/QM3FCUGC",
    },
    color: "#f0abfc",
    gradient: "linear-gradient(135deg, #f0abfc, #a78bfa)",
    features: [
      "Tout du plan Pro",
      "Multi-utilisateurs (10)",
      "Tableau de bord admin",
      "Intégrations Slack/Teams",
      "SLA 99.9%",
      "Support dédié 24/7",
      "Fine-tuning personnalisé",
    ],
  },
];

// ─── FAQ ─────────────────────────────────────────────────────────────────────

const FAQ = [
  {
    q: "Puis-je annuler à tout moment ?",
    a: "Oui, vous pouvez annuler votre abonnement à tout moment. Votre accès reste actif jusqu'à la fin de la période en cours.",
  },
  {
    q: "Comment fonctionnent les crédits gratuits ?",
    a: "Sans compte, vous bénéficiez de 5 messages gratuits pour tester Synova AI. Ensuite, un abonnement Premium est requis.",
  },
  {
    q: "Les paiements sont-ils sécurisés ?",
    a: "Oui, tous les paiements sont traités par SumUp, une plateforme certifiée PCI DSS. Vos données bancaires ne transitent jamais par nos serveurs.",
  },
  {
    q: "Y a-t-il une réduction annuelle ?",
    a: "Oui ! Avec l'abonnement annuel, vous économisez l'équivalent de 2 mois par rapport au tarif mensuel.",
  },
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function PricingPage() {
  const [isAnnual, setIsAnnual] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--bg)",
        color: "var(--text)",
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      {/* Nav */}
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: 60,
          background: "rgba(11,11,16,0.85)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: "1px solid var(--border)",
          display: "flex",
          alignItems: "center",
          padding: "0 32px",
          gap: 16,
          zIndex: 100,
        }}
      >
        <Link href="/">
          <button
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              color: "var(--text-muted)",
              background: "none",
              border: "none",
              cursor: "pointer",
              fontSize: "0.85rem",
              transition: "color 0.2s",
              padding: "6px 10px",
              borderRadius: 8,
            }}
            onMouseEnter={(e) =>
              (e.currentTarget.style.color = "var(--text)")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.color = "var(--text-muted)")
            }
          >
            <ArrowLeft size={15} />
            Retour au chat
          </button>
        </Link>

        <div style={{ flex: 1 }} />

        {/* Logo */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <div
            style={{
              width: 28,
              height: 28,
              background:
                "linear-gradient(135deg, var(--accent), var(--accent-2))",
              borderRadius: 8,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Sparkles size={13} color="white" />
          </div>
          <span
            style={{
              fontFamily: "'Syne', sans-serif",
              fontWeight: 800,
              fontSize: "1rem",
            }}
          >
            Synova AI
          </span>
        </div>
      </nav>

      {/* Content */}
      <div style={{ paddingTop: 60 }}>
        {/* Hero */}
        <section
          style={{
            textAlign: "center",
            padding: "72px 20px 48px",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* Background glow */}
          <div
            style={{
              position: "absolute",
              top: "20%",
              left: "50%",
              transform: "translateX(-50%)",
              width: 600,
              height: 300,
              background:
                "radial-gradient(ellipse, rgba(124,106,255,0.12) 0%, transparent 70%)",
              pointerEvents: "none",
            }}
          />

          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              padding: "5px 14px",
              background: "rgba(124,106,255,0.12)",
              border: "1px solid rgba(124,106,255,0.3)",
              borderRadius: 20,
              fontSize: "0.78rem",
              color: "var(--accent-2)",
              fontWeight: 600,
              marginBottom: 20,
              animation: "fadeIn 0.5s ease",
            }}
          >
            <Star size={11} fill="currentColor" />
            Économisez 2 mois avec l'abonnement annuel
          </div>

          <h1
            style={{
              fontSize: "clamp(2rem, 5vw, 3.2rem)",
              fontWeight: 800,
              lineHeight: 1.15,
              marginBottom: 16,
              background:
                "linear-gradient(135deg, var(--text) 40%, var(--accent-2))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              animation: "fadeIn 0.5s ease 0.1s both",
            }}
          >
            Choisissez votre plan
          </h1>

          <p
            style={{
              color: "var(--text-muted)",
              fontSize: "1rem",
              maxWidth: 480,
              margin: "0 auto 36px",
              animation: "fadeIn 0.5s ease 0.2s both",
            }}
          >
            Des tarifs transparents, sans frais cachés. Passez au niveau
            supérieur avec Synova AI Premium.
          </p>

          {/* Toggle */}
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              background: "var(--bg-3)",
              border: "1px solid var(--border)",
              borderRadius: 50,
              padding: 4,
              gap: 2,
              animation: "fadeIn 0.5s ease 0.3s both",
            }}
          >
            {["Mensuel", "Annuel"].map((label, i) => {
              const active = (i === 0 && !isAnnual) || (i === 1 && isAnnual);
              return (
                <button
                  key={label}
                  onClick={() => setIsAnnual(i === 1)}
                  style={{
                    padding: "8px 20px",
                    borderRadius: 50,
                    border: "none",
                    background: active
                      ? "linear-gradient(135deg, var(--accent), #6254e8)"
                      : "transparent",
                    color: active ? "white" : "var(--text-muted)",
                    fontSize: "0.88rem",
                    fontWeight: 600,
                    cursor: "pointer",
                    transition: "all 0.25s",
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                  }}
                >
                  {label}
                  {i === 1 && (
                    <span
                      style={{
                        background: active
                          ? "rgba(255,255,255,0.2)"
                          : "rgba(124,106,255,0.2)",
                        color: active ? "white" : "var(--accent-2)",
                        padding: "1px 7px",
                        borderRadius: 20,
                        fontSize: "0.68rem",
                        fontWeight: 700,
                      }}
                    >
                      -17%
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* Plans */}
        <section
          style={{
            padding: "0 20px 80px",
            maxWidth: 1000,
            margin: "0 auto",
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
              gap: 20,
              alignItems: "start",
            }}
          >
            {PLANS.map((plan, i) => (
              <div
                key={plan.name}
                style={{
                  background: plan.popular ? "var(--bg-3)" : "var(--bg-2)",
                  border: plan.popular
                    ? "1px solid rgba(124,106,255,0.4)"
                    : "1px solid var(--border)",
                  borderRadius: 20,
                  padding: plan.popular ? "32px 28px" : "28px",
                  position: "relative",
                  overflow: "hidden",
                  animation: `fadeIn 0.5s ease ${0.1 + i * 0.1}s both`,
                  transition: "transform 0.25s, box-shadow 0.25s",
                  cursor: "default",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                  e.currentTarget.style.boxShadow = plan.popular
                    ? "0 20px 60px rgba(124,106,255,0.2)"
                    : "0 20px 40px rgba(0,0,0,0.3)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                {/* Glow bg */}
                {plan.popular && (
                  <div
                    style={{
                      position: "absolute",
                      top: -60,
                      right: -60,
                      width: 200,
                      height: 200,
                      background:
                        "radial-gradient(circle, rgba(124,106,255,0.15), transparent 70%)",
                      pointerEvents: "none",
                    }}
                  />
                )}

                {/* Popular badge */}
                {plan.popular && (
                  <div
                    style={{
                      position: "absolute",
                      top: 16,
                      right: 16,
                      background:
                        "linear-gradient(135deg, var(--accent), #6254e8)",
                      color: "white",
                      padding: "3px 10px",
                      borderRadius: 20,
                      fontSize: "0.72rem",
                      fontWeight: 700,
                      fontFamily: "'Syne', sans-serif",
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    <Star size={9} fill="white" />
                    Populaire
                  </div>
                )}

                {/* Icon & name */}
                <div
                  style={{
                    width: 44,
                    height: 44,
                    background: plan.gradient,
                    borderRadius: 14,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    marginBottom: 16,
                  }}
                >
                  {plan.icon}
                </div>

                <h3
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: "1.15rem",
                    marginBottom: 4,
                    color: "var(--text)",
                  }}
                >
                  {plan.name}
                </h3>

                {/* Price */}
                <div style={{ marginBottom: 24 }}>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
                    <span
                      style={{
                        fontFamily: "'Syne', sans-serif",
                        fontSize: "2.8rem",
                        fontWeight: 800,
                        color: "var(--text)",
                        lineHeight: 1,
                      }}
                    >
                      {isAnnual
                        ? Math.round(plan.price.annual / 12)
                        : plan.price.monthly}
                      €
                    </span>
                    <span
                      style={{
                        color: "var(--text-muted)",
                        fontSize: "0.85rem",
                      }}
                    >
                      /mois
                    </span>
                  </div>
                  {isAnnual && (
                    <p
                      style={{
                        color: "var(--text-dim)",
                        fontSize: "0.78rem",
                        marginTop: 4,
                      }}
                    >
                      Facturé {plan.price.annual}€/an
                    </p>
                  )}
                </div>

                {/* CTA */}
                <a
                  href={isAnnual ? plan.link.annual : plan.link.monthly}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ display: "block", marginBottom: 24 }}
                >
                  <button
                    style={{
                      width: "100%",
                      padding: "12px",
                      background: plan.popular
                        ? plan.gradient
                        : "var(--bg-4)",
                      border: plan.popular
                        ? "none"
                        : "1px solid var(--border-hover)",
                      borderRadius: 12,
                      color: plan.popular ? "white" : "var(--text)",
                      fontFamily: "'Syne', sans-serif",
                      fontWeight: 700,
                      fontSize: "0.9rem",
                      cursor: "pointer",
                      transition: "all 0.2s",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 6,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = "0.88";
                      e.currentTarget.style.transform = "scale(1.01)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = "1";
                      e.currentTarget.style.transform = "scale(1)";
                    }}
                  >
                    {plan.popular && <Crown size={14} />}
                    Choisir {plan.name}
                  </button>
                </a>

                {/* Divider */}
                <div
                  style={{
                    height: 1,
                    background: "var(--border)",
                    marginBottom: 20,
                  }}
                />

                {/* Features */}
                <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 10 }}>
                  {plan.features.map((f) => (
                    <li
                      key={f}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        fontSize: "0.86rem",
                        color: "var(--text-muted)",
                      }}
                    >
                      <div
                        style={{
                          width: 18,
                          height: 18,
                          borderRadius: "50%",
                          background: "rgba(124,106,255,0.15)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        <Check size={10} color="var(--accent-2)" strokeWidth={3} />
                      </div>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Free tier reminder */}
        <section
          style={{
            maxWidth: 680,
            margin: "0 auto",
            padding: "0 20px 80px",
            textAlign: "center",
          }}
        >
          <div
            style={{
              background: "var(--bg-2)",
              border: "1px solid var(--border)",
              borderRadius: 20,
              padding: "32px",
            }}
          >
            <div
              style={{
                width: 48,
                height: 48,
                background: "var(--bg-4)",
                border: "1px solid var(--border)",
                borderRadius: 14,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 16px",
              }}
            >
              <Sparkles size={20} color="var(--accent-2)" />
            </div>
            <h3
              style={{
                fontFamily: "'Syne', sans-serif",
                fontWeight: 700,
                fontSize: "1.1rem",
                marginBottom: 8,
              }}
            >
              Essai gratuit inclus
            </h3>
            <p
              style={{
                color: "var(--text-muted)",
                fontSize: "0.9rem",
                marginBottom: 20,
                lineHeight: 1.6,
              }}
            >
              Testez Synova AI gratuitement avec{" "}
              <strong style={{ color: "var(--accent-2)" }}>
                5 messages offerts
              </strong>{" "}
              — aucune carte bancaire requise. Découvrez la puissance de l'IA
              avant de vous abonner.
            </p>
            <Link href="/">
              <button
                style={{
                  padding: "10px 24px",
                  background: "var(--bg-4)",
                  border: "1px solid var(--border-hover)",
                  borderRadius: 10,
                  color: "var(--text)",
                  fontWeight: 600,
                  fontSize: "0.88rem",
                  cursor: "pointer",
                  transition: "all 0.2s",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "var(--bg-3)";
                  e.currentTarget.style.borderColor = "rgba(124,106,255,0.4)";
                  e.currentTarget.style.color = "var(--accent-2)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "var(--bg-4)";
                  e.currentTarget.style.borderColor = "var(--border-hover)";
                  e.currentTarget.style.color = "var(--text)";
                }}
              >
                Essayer gratuitement →
              </button>
            </Link>
          </div>
        </section>

        {/* FAQ */}
        <section
          style={{
            maxWidth: 680,
            margin: "0 auto",
            padding: "0 20px 100px",
          }}
        >
          <h2
            style={{
              fontFamily: "'Syne', sans-serif",
              fontWeight: 800,
              fontSize: "1.6rem",
              textAlign: "center",
              marginBottom: 32,
            }}
          >
            Questions fréquentes
          </h2>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {FAQ.map((item, i) => (
              <div
                key={i}
                style={{
                  background: "var(--bg-2)",
                  border: `1px solid ${openFaq === i ? "rgba(124,106,255,0.3)" : "var(--border)"}`,
                  borderRadius: 14,
                  overflow: "hidden",
                  transition: "border-color 0.2s",
                }}
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  style={{
                    width: "100%",
                    padding: "16px 20px",
                    background: "none",
                    border: "none",
                    color: "var(--text)",
                    fontSize: "0.9rem",
                    fontWeight: 600,
                    textAlign: "left",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: 12,
                  }}
                >
                  {item.q}
                  <span
                    style={{
                      color: "var(--text-muted)",
                      fontSize: "1.2rem",
                      flexShrink: 0,
                      transform:
                        openFaq === i ? "rotate(45deg)" : "rotate(0)",
                      transition: "transform 0.2s",
                      display: "inline-block",
                    }}
                  >
                    +
                  </span>
                </button>
                {openFaq === i && (
                  <div
                    style={{
                      padding: "0 20px 16px",
                      color: "var(--text-muted)",
                      fontSize: "0.87rem",
                      lineHeight: 1.65,
                      animation: "fadeIn 0.2s ease",
                    }}
                  >
                    {item.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer
          style={{
            borderTop: "1px solid var(--border)",
            padding: "28px 20px",
            textAlign: "center",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              marginBottom: 8,
            }}
          >
            <div
              style={{
                width: 22,
                height: 22,
                background:
                  "linear-gradient(135deg, var(--accent), var(--accent-2))",
                borderRadius: 6,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Sparkles size={11} color="white" />
            </div>
            <span
              style={{
                fontFamily: "'Syne', sans-serif",
                fontWeight: 700,
                fontSize: "0.9rem",
              }}
            >
              Synova AI
            </span>
          </div>
          <p style={{ color: "var(--text-dim)", fontSize: "0.78rem" }}>
            © {new Date().getFullYear()} Synova AI. Tous droits réservés.
          </p>
        </footer>
      </div>
    </div>
  );
}
