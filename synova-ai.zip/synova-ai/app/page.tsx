"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  Send,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Plus,
  MessageSquare,
  Zap,
  Trash2,
  Copy,
  Check,
  AlertCircle,
  Crown,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Role = "user" | "assistant";

interface Message {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}

// ─── Constants ───────────────────────────────────────────────────────────────

const FREE_CREDITS = 5;
const STORAGE_CREDITS = "synova_credits";
const STORAGE_CONVERSATIONS = "synova_convs";

const SUGGESTIONS = [
  "Explique-moi l'intelligence artificielle simplement",
  "Rédige un email professionnel de relance",
  "Aide-moi à débugger mon code Python",
  "Propose un plan marketing pour mon SaaS",
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function uid(): string {
  return Math.random().toString(36).slice(2, 10);
}

function getCredits(): number {
  if (typeof window === "undefined") return FREE_CREDITS;
  const stored = localStorage.getItem(STORAGE_CREDITS);
  if (stored === null) {
    localStorage.setItem(STORAGE_CREDITS, String(FREE_CREDITS));
    return FREE_CREDITS;
  }
  return parseInt(stored, 10);
}

function setCredits(n: number): void {
  localStorage.setItem(STORAGE_CREDITS, String(n));
}

function loadConversations(): Conversation[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_CONVERSATIONS) || "[]");
  } catch {
    return [];
  }
}

function saveConversations(convs: Conversation[]): void {
  localStorage.setItem(STORAGE_CONVERSATIONS, JSON.stringify(convs));
}

function extractTitle(content: string): string {
  return content.length > 40 ? content.slice(0, 38) + "…" : content;
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function TypingDots() {
  return (
    <span style={{ display: "inline-flex", gap: 4, alignItems: "center" }}>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            background: "var(--accent-2)",
            animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
            display: "inline-block",
          }}
        />
      ))}
    </span>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      onClick={handleCopy}
      title="Copier"
      style={{
        background: "none",
        border: "none",
        cursor: "pointer",
        color: "var(--text-dim)",
        padding: "4px",
        borderRadius: 6,
        transition: "color 0.2s",
        display: "flex",
        alignItems: "center",
      }}
      onMouseEnter={(e) =>
        (e.currentTarget.style.color = "var(--text-muted)")
      }
      onMouseLeave={(e) =>
        (e.currentTarget.style.color = "var(--text-dim)")
      }
    >
      {copied ? (
        <Check size={13} color="var(--green)" />
      ) : (
        <Copy size={13} />
      )}
    </button>
  );
}

function MessageBubble({
  msg,
  isLast,
}: {
  msg: Message;
  isLast: boolean;
}) {
  const isUser = msg.role === "user";

  return (
    <div
      style={{
        display: "flex",
        flexDirection: isUser ? "row-reverse" : "row",
        gap: 12,
        alignItems: "flex-start",
        animation: isLast ? "fadeIn 0.3s ease" : undefined,
        maxWidth: "100%",
      }}
    >
      {/* Avatar */}
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: "50%",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 14,
          fontWeight: 700,
          fontFamily: "'Syne', sans-serif",
          background: isUser
            ? "linear-gradient(135deg, var(--accent), var(--accent-2))"
            : "var(--bg-4)",
          border: isUser ? "none" : "1px solid var(--border)",
          color: "white",
        }}
      >
        {isUser ? "V" : <Sparkles size={14} color="var(--accent-2)" />}
      </div>

      {/* Bubble */}
      <div style={{ maxWidth: "78%", minWidth: 0 }}>
        <div
          style={{
            background: isUser
              ? "linear-gradient(135deg, var(--accent) 0%, #6254e8 100%)"
              : "var(--bg-3)",
            border: isUser ? "none" : "1px solid var(--border)",
            borderRadius: isUser
              ? "18px 4px 18px 18px"
              : "4px 18px 18px 18px",
            padding: "12px 16px",
            color: "var(--text)",
            fontSize: "0.9rem",
            lineHeight: 1.65,
            wordBreak: "break-word",
            whiteSpace: "pre-wrap",
            position: "relative",
          }}
        >
          {msg.content}
        </div>

        {/* Actions */}
        {!isUser && (
          <div
            style={{
              marginTop: 4,
              display: "flex",
              gap: 4,
              paddingLeft: 4,
            }}
          >
            <CopyButton text={msg.content} />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function ChatPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [credits, setCreditsState] = useState(FREE_CREDITS);
  const [error, setError] = useState<string | null>(null);
  const [showUpgrade, setShowUpgrade] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // ── Init ────────────────────────────────────────────────────────────────────
  useEffect(() => {
    setCreditsState(getCredits());
    const convs = loadConversations();
    setConversations(convs);
    if (convs.length > 0) setActiveId(convs[0].id);
  }, []);

  // ── Active conversation ──────────────────────────────────────────────────────
  const activeConv = conversations.find((c) => c.id === activeId) ?? null;
  const messages = activeConv?.messages ?? [];

  // ── Scroll to bottom ────────────────────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // ── Textarea auto-resize ─────────────────────────────────────────────────────
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
  }, [input]);

  // ── New chat ─────────────────────────────────────────────────────────────────
  const newChat = useCallback(() => {
    const conv: Conversation = {
      id: uid(),
      title: "Nouvelle conversation",
      messages: [],
      createdAt: Date.now(),
    };
    const updated = [conv, ...conversations];
    setConversations(updated);
    saveConversations(updated);
    setActiveId(conv.id);
    setError(null);
    setShowUpgrade(false);
  }, [conversations]);

  // ── Delete conversation ──────────────────────────────────────────────────────
  const deleteConv = useCallback(
    (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      const updated = conversations.filter((c) => c.id !== id);
      setConversations(updated);
      saveConversations(updated);
      if (activeId === id) {
        setActiveId(updated[0]?.id ?? null);
      }
    },
    [conversations, activeId]
  );

  // ── Send message ─────────────────────────────────────────────────────────────
  const sendMessage = useCallback(
    async (text?: string) => {
      const content = (text ?? input).trim();
      if (!content || loading) return;

      // Check credits
      const currentCredits = getCredits();
      if (currentCredits <= 0) {
        setShowUpgrade(true);
        return;
      }

      setError(null);
      setShowUpgrade(false);
      setInput("");

      // Get or create conversation
      let convId = activeId;
      let allConvs = [...conversations];

      if (!convId) {
        const conv: Conversation = {
          id: uid(),
          title: extractTitle(content),
          messages: [],
          createdAt: Date.now(),
        };
        allConvs = [conv, ...allConvs];
        convId = conv.id;
        setActiveId(convId);
      }

      // Add user message
      const userMsg: Message = {
        id: uid(),
        role: "user",
        content,
        createdAt: Date.now(),
      };

      const updatedConvs = allConvs.map((c) => {
        if (c.id !== convId) return c;
        const msgs = [...c.messages, userMsg];
        return {
          ...c,
          title: c.messages.length === 0 ? extractTitle(content) : c.title,
          messages: msgs,
        };
      });

      setConversations(updatedConvs);
      saveConversations(updatedConvs);
      setLoading(true);

      // Decrement credits
      const newCredits = currentCredits - 1;
      setCredits(newCredits);
      setCreditsState(newCredits);

      try {
        const currentMessages =
          updatedConvs.find((c) => c.id === convId)?.messages ?? [];

        const res = await fetch("/api/ai", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: currentMessages.map((m) => ({
              role: m.role,
              content: m.content,
            })),
          }),
        });

        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Erreur serveur");
        }

        const assistantMsg: Message = {
          id: uid(),
          role: "assistant",
          content: data.reply,
          createdAt: Date.now(),
        };

        const finalConvs = updatedConvs.map((c) => {
          if (c.id !== convId) return c;
          return { ...c, messages: [...c.messages, assistantMsg] };
        });

        setConversations(finalConvs);
        saveConversations(finalConvs);
      } catch (err: unknown) {
        const msg =
          err instanceof Error ? err.message : "Une erreur est survenue.";
        setError(msg);
        // Refund credit on error
        const refund = getCredits() + 1;
        setCredits(refund);
        setCreditsState(refund);
      } finally {
        setLoading(false);
      }
    },
    [input, loading, activeId, conversations]
  );

  // ── Keyboard handler ─────────────────────────────────────────────────────────
  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────────

  return (
    <div
      style={{
        display: "flex",
        height: "100vh",
        background: "var(--bg)",
        overflow: "hidden",
      }}
    >
      {/* ── Sidebar ─────────────────────────────────────────────────────────── */}
      <aside
        style={{
          width: sidebarOpen ? "var(--sidebar-w)" : "0",
          minWidth: sidebarOpen ? "var(--sidebar-w)" : "0",
          overflow: "hidden",
          transition: "width 0.3s ease, min-width 0.3s ease",
          background: "var(--bg-2)",
          borderRight: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          position: "relative",
        }}
      >
        <div
          style={{
            width: "var(--sidebar-w)",
            display: "flex",
            flexDirection: "column",
            height: "100%",
            overflow: "hidden",
          }}
        >
          {/* Logo */}
          <div
            style={{
              padding: "20px 16px 12px",
              borderBottom: "1px solid var(--border)",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                marginBottom: 16,
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  background:
                    "linear-gradient(135deg, var(--accent), var(--accent-2))",
                  borderRadius: 10,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  animation: "glowPulse 3s ease-in-out infinite",
                }}
              >
                <Sparkles size={16} color="white" />
              </div>
              <span
                style={{
                  fontFamily: "'Syne', sans-serif",
                  fontWeight: 800,
                  fontSize: "1.1rem",
                  letterSpacing: "-0.02em",
                  color: "var(--text)",
                }}
              >
                Synova AI
              </span>
            </div>

            {/* New chat button */}
            <button
              onClick={newChat}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                gap: 8,
                padding: "9px 12px",
                background: "var(--bg-4)",
                border: "1px solid var(--border)",
                borderRadius: 10,
                color: "var(--text)",
                fontSize: "0.85rem",
                fontWeight: 500,
                transition: "all 0.2s",
                cursor: "pointer",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "var(--accent)";
                e.currentTarget.style.borderColor = "var(--accent)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "var(--bg-4)";
                e.currentTarget.style.borderColor = "var(--border)";
              }}
            >
              <Plus size={15} />
              Nouveau chat
            </button>
          </div>

          {/* Conversations list */}
          <div
            style={{
              flex: 1,
              overflowY: "auto",
              padding: "8px",
            }}
          >
            {conversations.length === 0 ? (
              <p
                style={{
                  textAlign: "center",
                  color: "var(--text-dim)",
                  fontSize: "0.8rem",
                  padding: "24px 16px",
                }}
              >
                Aucune conversation
              </p>
            ) : (
              conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => {
                    setActiveId(conv.id);
                    setError(null);
                    setShowUpgrade(false);
                  }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    padding: "9px 10px",
                    borderRadius: 9,
                    cursor: "pointer",
                    background:
                      activeId === conv.id
                        ? "var(--bg-4)"
                        : "transparent",
                    border:
                      activeId === conv.id
                        ? "1px solid var(--border)"
                        : "1px solid transparent",
                    marginBottom: 2,
                    transition: "all 0.15s",
                    animation: "slideIn 0.2s ease",
                    group: "true",
                  }}
                  onMouseEnter={(e) => {
                    if (activeId !== conv.id)
                      e.currentTarget.style.background = "var(--bg-3)";
                  }}
                  onMouseLeave={(e) => {
                    if (activeId !== conv.id)
                      e.currentTarget.style.background = "transparent";
                  }}
                >
                  <MessageSquare
                    size={13}
                    color={
                      activeId === conv.id
                        ? "var(--accent-2)"
                        : "var(--text-dim)"
                    }
                    style={{ flexShrink: 0 }}
                  />
                  <span
                    style={{
                      flex: 1,
                      fontSize: "0.82rem",
                      color:
                        activeId === conv.id
                          ? "var(--text)"
                          : "var(--text-muted)",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      minWidth: 0,
                    }}
                  >
                    {conv.title}
                  </span>
                  <button
                    onClick={(e) => deleteConv(conv.id, e)}
                    style={{
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      color: "var(--text-dim)",
                      padding: 3,
                      borderRadius: 5,
                      display: "flex",
                      opacity: 0.6,
                      transition: "opacity 0.2s, color 0.2s",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = "1";
                      e.currentTarget.style.color = "var(--red)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = "0.6";
                      e.currentTarget.style.color = "var(--text-dim)";
                    }}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Credits */}
          <div
            style={{
              padding: "12px 16px",
              borderTop: "1px solid var(--border)",
            }}
          >
            <div
              style={{
                background: "var(--bg-3)",
                border: "1px solid var(--border)",
                borderRadius: 10,
                padding: "10px 12px",
                marginBottom: 10,
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 6,
                }}
              >
                <span
                  style={{
                    fontSize: "0.75rem",
                    color: "var(--text-muted)",
                    fontWeight: 500,
                  }}
                >
                  Crédits restants
                </span>
                <span
                  style={{
                    fontSize: "0.8rem",
                    fontWeight: 700,
                    color:
                      credits > 2
                        ? "var(--accent-2)"
                        : credits > 0
                        ? "#f59e0b"
                        : "var(--red)",
                    fontFamily: "'Syne', sans-serif",
                  }}
                >
                  {credits} / {FREE_CREDITS}
                </span>
              </div>
              {/* Progress bar */}
              <div
                style={{
                  height: 4,
                  background: "var(--bg-4)",
                  borderRadius: 4,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${(credits / FREE_CREDITS) * 100}%`,
                    background:
                      credits > 2
                        ? "linear-gradient(90deg, var(--accent), var(--accent-2))"
                        : credits > 0
                        ? "#f59e0b"
                        : "var(--red)",
                    borderRadius: 4,
                    transition: "width 0.4s ease",
                  }}
                />
              </div>
            </div>

            <Link href="/pricing">
              <button
                style={{
                  width: "100%",
                  padding: "9px",
                  background:
                    "linear-gradient(135deg, var(--accent), #6254e8)",
                  border: "none",
                  borderRadius: 10,
                  color: "white",
                  fontSize: "0.82rem",
                  fontWeight: 600,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  transition: "opacity 0.2s",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.opacity = "0.88")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.opacity = "1")
                }
              >
                <Crown size={13} />
                Passer Premium
              </button>
            </Link>
          </div>
        </div>
      </aside>

      {/* ── Main area ───────────────────────────────────────────────────────── */}
      <main
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          position: "relative",
          minWidth: 0,
        }}
      >
        {/* Header */}
        <header
          style={{
            height: 54,
            borderBottom: "1px solid var(--border)",
            display: "flex",
            alignItems: "center",
            padding: "0 16px",
            gap: 12,
            background: "var(--bg)",
            flexShrink: 0,
          }}
        >
          {/* Toggle sidebar */}
          <button
            onClick={() => setSidebarOpen((o) => !o)}
            style={{
              width: 32,
              height: 32,
              borderRadius: 8,
              border: "1px solid var(--border)",
              background: "var(--bg-3)",
              color: "var(--text-muted)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              transition: "all 0.2s",
              flexShrink: 0,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "var(--bg-4)";
              e.currentTarget.style.color = "var(--text)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "var(--bg-3)";
              e.currentTarget.style.color = "var(--text-muted)";
            }}
          >
            {sidebarOpen ? (
              <ChevronLeft size={15} />
            ) : (
              <ChevronRight size={15} />
            )}
          </button>

          {/* Title */}
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Zap size={15} color="var(--accent-2)" />
            <span
              style={{
                fontFamily: "'Syne', sans-serif",
                fontWeight: 600,
                fontSize: "0.9rem",
                color: "var(--text)",
              }}
            >
              {activeConv ? activeConv.title : "Synova AI"}
            </span>
          </div>

          <div style={{ flex: 1 }} />

          {/* Model badge */}
          <div
            style={{
              padding: "4px 10px",
              background: "var(--bg-3)",
              border: "1px solid var(--border)",
              borderRadius: 20,
              fontSize: "0.73rem",
              color: "var(--text-muted)",
              fontWeight: 500,
              display: "flex",
              alignItems: "center",
              gap: 5,
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "var(--green)",
                display: "inline-block",
              }}
            />
            GPT-4o mini
          </div>

          <Link href="/pricing">
            <button
              style={{
                padding: "6px 14px",
                background:
                  "linear-gradient(135deg, var(--accent), #6254e8)",
                border: "none",
                borderRadius: 8,
                color: "white",
                fontSize: "0.78rem",
                fontWeight: 600,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 5,
                transition: "opacity 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.opacity = "0.85")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.opacity = "1")
              }
            >
              <Crown size={12} />
              Upgrade
            </button>
          </Link>
        </header>

        {/* Messages area */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "24px 0",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 740,
              margin: "0 auto",
              padding: "0 20px",
              display: "flex",
              flexDirection: "column",
              gap: 20,
              flex: 1,
            }}
          >
            {messages.length === 0 && !loading ? (
              /* Empty state */
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 32,
                  paddingBottom: 60,
                }}
              >
                {/* Hero */}
                <div style={{ textAlign: "center" }}>
                  <div
                    style={{
                      width: 64,
                      height: 64,
                      background:
                        "linear-gradient(135deg, var(--accent), var(--accent-2))",
                      borderRadius: 20,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 20px",
                      animation: "glowPulse 3s ease-in-out infinite",
                    }}
                  >
                    <Sparkles size={28} color="white" />
                  </div>
                  <h1
                    style={{
                      fontSize: "1.8rem",
                      fontWeight: 800,
                      marginBottom: 8,
                      background:
                        "linear-gradient(135deg, var(--text) 30%, var(--accent-2))",
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      backgroundClip: "text",
                    }}
                  >
                    Synova AI
                  </h1>
                  <p
                    style={{
                      color: "var(--text-muted)",
                      fontSize: "0.95rem",
                      maxWidth: 360,
                    }}
                  >
                    Votre assistant IA de nouvelle génération. Posez n'importe
                    quelle question.
                  </p>
                </div>

                {/* Suggestions */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    width: "100%",
                    maxWidth: 600,
                  }}
                >
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      onClick={() => sendMessage(s)}
                      style={{
                        padding: "12px 16px",
                        background: "var(--bg-3)",
                        border: "1px solid var(--border)",
                        borderRadius: 12,
                        color: "var(--text-muted)",
                        fontSize: "0.82rem",
                        textAlign: "left",
                        cursor: "pointer",
                        transition: "all 0.2s",
                        lineHeight: 1.4,
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = "var(--bg-4)";
                        e.currentTarget.style.borderColor =
                          "var(--border-hover)";
                        e.currentTarget.style.color = "var(--text)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = "var(--bg-3)";
                        e.currentTarget.style.borderColor = "var(--border)";
                        e.currentTarget.style.color = "var(--text-muted)";
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              /* Messages */
              <>
                {messages.map((msg, i) => (
                  <MessageBubble
                    key={msg.id}
                    msg={msg}
                    isLast={i === messages.length - 1}
                  />
                ))}
                {loading && (
                  <div
                    style={{
                      display: "flex",
                      gap: 12,
                      alignItems: "flex-start",
                      animation: "fadeIn 0.3s ease",
                    }}
                  >
                    <div
                      style={{
                        width: 32,
                        height: 32,
                        borderRadius: "50%",
                        background: "var(--bg-4)",
                        border: "1px solid var(--border)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      <Sparkles size={14} color="var(--accent-2)" />
                    </div>
                    <div
                      style={{
                        background: "var(--bg-3)",
                        border: "1px solid var(--border)",
                        borderRadius: "4px 18px 18px 18px",
                        padding: "14px 18px",
                      }}
                    >
                      <TypingDots />
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Error */}
            {error && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "12px 16px",
                  background: "rgba(248, 113, 113, 0.08)",
                  border: "1px solid rgba(248, 113, 113, 0.2)",
                  borderRadius: 10,
                  color: "var(--red)",
                  fontSize: "0.85rem",
                  animation: "fadeIn 0.3s ease",
                }}
              >
                <AlertCircle size={15} />
                {error}
              </div>
            )}

            <div ref={bottomRef} />
          </div>
        </div>

        {/* Upgrade banner */}
        {showUpgrade && (
          <div
            style={{
              padding: "0 20px 12px",
              maxWidth: 740,
              width: "100%",
              margin: "0 auto",
              animation: "fadeIn 0.3s ease",
            }}
          >
            <div
              style={{
                background:
                  "linear-gradient(135deg, rgba(124,106,255,0.15), rgba(167,139,250,0.08))",
                border: "1px solid rgba(124,106,255,0.35)",
                borderRadius: 14,
                padding: "16px 20px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 16,
                flexWrap: "wrap",
              }}
            >
              <div>
                <div
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: "0.95rem",
                    color: "var(--text)",
                    marginBottom: 2,
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                  }}
                >
                  <Crown size={15} color="var(--accent-2)" />
                  Crédits épuisés
                </div>
                <p
                  style={{
                    color: "var(--text-muted)",
                    fontSize: "0.83rem",
                  }}
                >
                  Passez Premium pour continuer à utiliser Synova AI sans
                  limite.
                </p>
              </div>
              <Link href="/pricing">
                <button
                  style={{
                    padding: "10px 20px",
                    background:
                      "linear-gradient(135deg, var(--accent), #6254e8)",
                    border: "none",
                    borderRadius: 10,
                    color: "white",
                    fontWeight: 700,
                    fontSize: "0.85rem",
                    fontFamily: "'Syne', sans-serif",
                    cursor: "pointer",
                    whiteSpace: "nowrap",
                    transition: "opacity 0.2s",
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.opacity = "0.85")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.opacity = "1")
                  }
                >
                  Voir les offres →
                </button>
              </Link>
            </div>
          </div>
        )}

        {/* Input area */}
        <div
          style={{
            padding: "12px 20px 20px",
            background: "var(--bg)",
            borderTop: "1px solid var(--border)",
            flexShrink: 0,
          }}
        >
          <div
            style={{
              maxWidth: 740,
              margin: "0 auto",
              position: "relative",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "flex-end",
                gap: 10,
                background: "var(--bg-3)",
                border: `1px solid ${credits <= 0 ? "rgba(248,113,113,0.3)" : "var(--border)"}`,
                borderRadius: 16,
                padding: "10px 12px 10px 16px",
                transition: "border-color 0.2s, box-shadow 0.2s",
              }}
              onFocusCapture={(e) => {
                const el = e.currentTarget as HTMLDivElement;
                if (credits > 0) {
                  el.style.borderColor = "rgba(124,106,255,0.5)";
                  el.style.boxShadow = "0 0 0 3px rgba(124,106,255,0.08)";
                }
              }}
              onBlurCapture={(e) => {
                const el = e.currentTarget as HTMLDivElement;
                el.style.borderColor =
                  credits <= 0
                    ? "rgba(248,113,113,0.3)"
                    : "var(--border)";
                el.style.boxShadow = "none";
              }}
            >
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  credits <= 0
                    ? "Crédits épuisés — passez Premium"
                    : "Posez votre question… (Entrée pour envoyer)"
                }
                disabled={loading || credits <= 0}
                rows={1}
                style={{
                  flex: 1,
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: credits <= 0 ? "var(--text-dim)" : "var(--text)",
                  fontSize: "0.9rem",
                  resize: "none",
                  maxHeight: 160,
                  lineHeight: 1.6,
                  padding: "2px 0",
                  overflowY: "auto",
                }}
              />

              <button
                onClick={() => sendMessage()}
                disabled={loading || !input.trim() || credits <= 0}
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  background:
                    !input.trim() || loading || credits <= 0
                      ? "var(--bg-4)"
                      : "linear-gradient(135deg, var(--accent), #6254e8)",
                  border: "none",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor:
                    !input.trim() || loading || credits <= 0
                      ? "not-allowed"
                      : "pointer",
                  transition: "all 0.2s",
                  flexShrink: 0,
                  opacity: !input.trim() || loading || credits <= 0 ? 0.5 : 1,
                }}
              >
                {loading ? (
                  <div
                    style={{
                      width: 14,
                      height: 14,
                      border: "2px solid var(--text-dim)",
                      borderTopColor: "var(--accent-2)",
                      borderRadius: "50%",
                      animation: "spin 0.8s linear infinite",
                    }}
                  />
                ) : (
                  <Send size={14} color="white" />
                )}
              </button>
            </div>

            <p
              style={{
                textAlign: "center",
                color: "var(--text-dim)",
                fontSize: "0.72rem",
                marginTop: 8,
              }}
            >
              Synova AI peut faire des erreurs. Vérifiez les informations
              importantes.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
